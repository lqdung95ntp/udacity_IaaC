Working test url: 
http://udagr-webap-1gm3gnk0jzqn5-139448758.us-east-1.elb.amazonaws.com/